package com.api.model;

public class GeoLocationModel {

	private String city;

	private String country;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

//	"country": "Canada",
//	  "countryCode": "CA",
//	  "region": "QC",
//	  "regionName": "Quebec",
//	  "city": "Montreal",
//	  "zip": "H1A",

}
